/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.main;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */



import java.util.Scanner;




public class Main { 

    public static void main(String[] args) { 

        Scanner scanner = new Scanner(System.in); 

        ChatSecure chatSecure = new ChatSecure(); 

 

        System.out.println("Welcome to Chat Secure!"); 

 

        System.out.print("Enter first name: "); 

        String firstName = scanner.nextLine(); 

 

        System.out.print("Enter last name: "); 

        String lastName = scanner.nextLine(); 

 

        System.out.print("Enter username: "); 

        String username = scanner.nextLine(); 

 

        System.out.print("Enter password: "); 

        String password = scanner.nextLine(); 

 

        System.out.print("Enter phone number (e.g., +27830000000): "); 

        String phone = scanner.nextLine(); 

 

        String result = chatSecure.registerUser(username, password, phone, firstName, lastName); 

        System.out.println(result); 

 

        if (result.equals("User registered successfully!")) { 
            System.out.println("\nPlease log in."); 

 

            System.out.print("Username: "); 
            String loginUsername = scanner.nextLine(); 

 

            System.out.print("Password: "); 
            String loginPassword = scanner.nextLine(); 

 

            String loginMessage = chatSecure.returnLoginStatus(loginUsername, loginPassword); 
            System.out.println(loginMessage); 

        } 
        scanner.close(); 

    } 

}   
    

